gen_ae_hjs <<!
1   !   AU & Years
plhjs.in
654876543
10 !  # of first set of test particles
-1 -1 -1 ! orbct : tp's orbit bodies 1, 2 and 3
0. 0.1  ! Ecc's
3.  ! Max inc
10. 15. ! Amin & Amax
0.     ! Power index
5 !  # of second set of test particles
-1 -1 0 ! orbct : tp's orbit bodies 1 and 2 
0. 0.1  ! Ecc's
3.  ! Max inc
0.3 0.4 ! Amin & Amax
0.     ! Power index
5 !  # of third set of test particles
0 0 -1 ! orbct : tp's orbit body 3
0. 0.1  ! Ecc's
3.  ! Max inc
0.05 0.1 ! Amin & Amax
0.     ! Power index
0     ! 4th set of tp's => dummy
tphjs_3.in
!
exit
