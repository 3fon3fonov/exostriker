gen_pl_hjs <<!
1   !   AU & Years
1   !   Invariable plane
5   !  # of bodies in the system
2.97704   !
1.56918   !
1.26 ! Masses of bodies in solar masses
0.5
0.7
-1 1 0 0 0! Orbit 1 : Body #2 orbiting Body #1
0.0656 0.0216 90. 0. -18.0 0.0
-1 -1 1 0 0 ! Orbit 2 : Body #3 orbiting Body #1 + Body #2
1.47 0.507 20. -100. 153. 0.0
0 0 0 -1 1 ! Orbit 3 : Body #5 orbiting Body #4
0.1 0.1 40. 0. -18.0 0.0
-1 -1 -1 1 1 ! Orbit 4 : Bodies #4,5 orbiting Bodies #1,2,3
25 0.4 20. 0. 150.0 0.0
plhjs_5.in
!
exit
