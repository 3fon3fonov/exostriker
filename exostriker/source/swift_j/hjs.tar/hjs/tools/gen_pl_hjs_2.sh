gen_pl_hjs <<!
1   !   AU & Years
1   !   Invariable plane
2   !  # of bodies in the system
0.533   !
0.467   !
-1 1 ! Orbit 1 : Body #2 orbiting Body #1
1. 0.7 0.0d0 0.0d0 0.0d0 0.0d0 ! Orbit 1
plhjs.in
!
exit
